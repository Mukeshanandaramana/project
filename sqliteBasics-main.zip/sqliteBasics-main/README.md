# sqliteBasics
create a database, insert data and easily select it with Sqlite
<br>
<br>
![Sqlite Tutorial Thumbnail](https://user-images.githubusercontent.com/32107652/142879160-689e9aba-42ff-4134-aefd-a2e0224a00da.png)
<br>
#### Watch on YouTube
a step by step tutorial explaining this code:
<br>
https://youtu.be/Ohj-CqALrwk
<br>
#### Useful Infromation
<b>Author:</b> Mariya Sha
<br>
<b>Dependencies:</b> Sqlite 3
<br>
https://docs.python.org/3/library/sqlite3.html
<br>
<b>IDE:</b> Wayscript X
<br>
please note - it's not yet available for the wide public but you can request an invitation here:
<br>
https://wayscript.com/wsx
<br>
Or you can learn more about Wayscript X here:
<br>
https://wsxdocs.wayscript.com/
<br>
<br>
Feel free to use this code in whichever way you'd like!
<br>
I really hope you'll find it helpful! :)

